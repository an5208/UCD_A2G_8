From proto.io: "This is a prototype built with Proto.io."

Please open the preview.html file with your browser to view the prototype.

All resources used in the prototype are from:
- Proto.io library
- "Bao Tang Chien Thang B52" (B52 Victory Museum) website, the subject of this prototype and project.